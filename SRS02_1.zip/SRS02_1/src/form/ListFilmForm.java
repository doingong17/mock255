package form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import model.bean.Character;
import model.bean.Film;
import model.bean.FilmName;
import model.bean.LiberationTime;

public class ListFilmForm extends ActionForm{
	private String filmId;
	private String characterId;
	private String liberationTimeId;
	private String liberationTimeName;
	private String characterName;
	private String filmName;
	private String filmDayOfWeek;
	private String filmDayOfYear;
	private String filmTime;
	private ArrayList<Film> listFilm;
	private ArrayList<FilmName> listFilmName;
	private ArrayList<Character> listCharacter;
	private ArrayList<LiberationTime> listLiberationTime;
	private String submit;
	private String action;
	private String action1;
	private int page;
	private int noOfPages;
	private int currentPage;
	private ArrayList<Integer> listPage;	
	
	
	/**
	 * @return the action1
	 */
	public String getAction1() {
		return action1;
	}
	/**
	 * @param action1 the action1 to set
	 */
	public void setAction1(String action1) {
		this.action1 = action1;
	}
	/**
	 * @return the noOfPages
	 */
	public int getNoOfPages() {
		return noOfPages;
	}
	/**
	 * @param noOfPages the noOfPages to set
	 */
	public void setNoOfPages(int noOfPages) {
		this.noOfPages = noOfPages;
	}
	/**
	 * @return the currentPage
	 */
	public int getCurrentPage() {
		return currentPage;
	}
	/**
	 * @param currentPage the currentPage to set
	 */
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	/**
	 * @return the listPage
	 */
	public ArrayList<Integer> getListPage() {
		return listPage;
	}
	/**
	 * @param listPage the listPage to set
	 */
	public void setListPage(ArrayList<Integer> listPage) {
		this.listPage = listPage;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the page
	 */
	public int getPage() {
		return page;
	}
	/**
	 * @param page the page to set
	 */
	public void setPage(int page) {
		this.page = page;
	}
	/**
	 * @return the filmDayOfWeek
	 */
	public String getFilmDayOfWeek() {
		return filmDayOfWeek;
	}
	/**
	 * @param filmDayOfWeek the filmDayOfWeek to set
	 */
	public void setFilmDayOfWeek(String filmDayOfWeek) {
		this.filmDayOfWeek = filmDayOfWeek;
	}
	/**
	 * @return the filmDayOfYear
	 */
	public String getFilmDayOfYear() {
		return filmDayOfYear;
	}
	/**
	 * @param filmDayOfYear the filmDayOfYear to set
	 */
	public void setFilmDayOfYear(String filmDayOfYear) {
		this.filmDayOfYear = filmDayOfYear;
	}
	/**
	 * @return the filmTime
	 */
	public String getFilmTime() {
		return filmTime;
	}
	/**
	 * @param filmTime the filmTime to set
	 */
	public void setFilmTime(String filmTime) {
		this.filmTime = filmTime;
	}
	/**
	 * @return the liberationTimeName
	 */
	public String getLiberationTimeName() {
		return liberationTimeName;
	}
	/**
	 * @param liberationTimeName the liberationTimeName to set
	 */
	public void setLiberationTimeName(String liberationTimeName) {
		this.liberationTimeName = liberationTimeName;
	}
	/**
	 * @return the characterName
	 */
	public String getCharacterName() {
		return characterName;
	}
	/**
	 * @param characterName the characterName to set
	 */
	public void setCharacterName(String characterName) {
		this.characterName = characterName;
	}
	/**
	 * @return the filmName
	 */
	public String getFilmName() {
		return filmName;
	}
	/**
	 * @param filmName the filmName to set
	 */
	public void setFilmName(String filmName) {
		this.filmName = filmName;
	}
	/**
	 * @return the submit
	 */
	public String getSubmit() {
		return submit;
	}
	/**
	 * @param submit the submit to set
	 */
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	/**
	 * @return the filmId
	 */
	public String getFilmId() {
		return filmId;
	}
	/**
	 * @param filmId the filmId to set
	 */
	public void setFilmId(String filmId) {
		this.filmId = filmId;
	}
	/**
	 * @return the characterId
	 */
	public String getCharacterId() {
		return characterId;
	}
	/**
	 * @param characterId the characterId to set
	 */
	public void setCharacterId(String characterId) {
		this.characterId = characterId;
	}
	/**
	 * @return the liberationTimeId
	 */
	public String getLiberationTimeId() {
		return liberationTimeId;
	}
	/**
	 * @param liberationTimeId the liberationTimeId to set
	 */
	public void setLiberationTimeId(String liberationTimeId) {
		this.liberationTimeId = liberationTimeId;
	}
	/**
	 * @return the listFilm
	 */
	public ArrayList<Film> getListFilm() {
		return listFilm;
	}
	/**
	 * @param listFilm the listFilm to set
	 */
	public void setListFilm(ArrayList<Film> listFilm) {
		this.listFilm = listFilm;
	}
	/**
	 * @return the listFilmName
	 */
	public ArrayList<FilmName> getListFilmName() {
		return listFilmName;
	}
	/**
	 * @param listFilmName the listFilmName to set
	 */
	public void setListFilmName(ArrayList<FilmName> listFilmName) {
		this.listFilmName = listFilmName;
	}
	/**
	 * @return the listCharacter
	 */
	public ArrayList<Character> getListCharacter() {
		return listCharacter;
	}
	/**
	 * @param listCharacter the listCharacter to set
	 */
	public void setListCharacter(ArrayList<Character> listCharacter) {
		this.listCharacter = listCharacter;
	}
	/**
	 * @return the listLiberationTime
	 */
	public ArrayList<LiberationTime> getListLiberationTime() {
		return listLiberationTime;
	}
	/**
	 * @param listLiberationTime the listLiberationTime to set
	 */
	public void setListLiberationTime(ArrayList<LiberationTime> listLiberationTime) {
		this.listLiberationTime = listLiberationTime;
	}
	/* (non-Javadoc)
	 * @see org.apache.struts.action.ActionForm#reset(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		// TODO Auto-generated method stub
		try {
			request.setCharacterEncoding("UTF-8");
			} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
