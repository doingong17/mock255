package model.bo;

import java.util.ArrayList;

import model.bean.LiberationTime;
import model.dao.LiberationTimeDAO;

/**
 * LiberationTimeBO.java
 *
 * Version 1.0
 *
 * Date: 04-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-05-2017        	CuongHM4        Create
 */

public class LiberationTimeBO {
	LiberationTimeDAO liberationTime = new LiberationTimeDAO();
	
	/**
	 * Hàm get danh sách tất cả LiberationTime
	 * @return list
	 */
	public ArrayList<LiberationTime> getListLiberationTime() {
		return liberationTime.getListLiberationTime();
	}
}
